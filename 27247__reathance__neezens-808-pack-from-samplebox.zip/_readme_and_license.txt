Pack downloaded from Freesound
----------------------------------------

"neezen&#x27;s 808 pack [from samplebox]"

This Pack of sounds contains sounds by the following user:
 - reathance ( https://freesound.org/people/reathance/ )

You can find this pack online at: https://freesound.org/people/reathance/packs/27247/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 482123__reathance__chorus-808.mp3.mp3
    * url: https://freesound.org/s/482123/
    * license: Creative Commons 0
  * 482077__reathance__808-9.wav.wav
    * url: https://freesound.org/s/482077/
    * license: Creative Commons 0
  * 482076__reathance__808-with-a-lot-of-hi-ends.wav.wav
    * url: https://freesound.org/s/482076/
    * license: Creative Commons 0
  * 482075__reathance__808-5.wav.wav
    * url: https://freesound.org/s/482075/
    * license: Creative Commons 0
  * 482074__reathance__808-6.wav.wav
    * url: https://freesound.org/s/482074/
    * license: Creative Commons 0
  * 482073__reathance__808-7.wav.wav
    * url: https://freesound.org/s/482073/
    * license: Creative Commons 0
  * 482072__reathance__808-8.wav.wav
    * url: https://freesound.org/s/482072/
    * license: Creative Commons 0
  * 482071__reathance__808-1.wav.wav
    * url: https://freesound.org/s/482071/
    * license: Creative Commons 0
  * 482070__reathance__808-2.wav.wav
    * url: https://freesound.org/s/482070/
    * license: Creative Commons 0
  * 482069__reathance__808-3.wav.wav
    * url: https://freesound.org/s/482069/
    * license: Creative Commons 0
  * 482068__reathance__808-4.wav.wav
    * url: https://freesound.org/s/482068/
    * license: Creative Commons 0
  * 482067__reathance__bad-808-14.wav.wav
    * url: https://freesound.org/s/482067/
    * license: Creative Commons 0
  * 482066__reathance__bad-808-15.wav.wav
    * url: https://freesound.org/s/482066/
    * license: Creative Commons 0
  * 482065__reathance__bad-808-10.wav.wav
    * url: https://freesound.org/s/482065/
    * license: Creative Commons 0
  * 482064__reathance__bad-808-11.wav.wav
    * url: https://freesound.org/s/482064/
    * license: Creative Commons 0
  * 482063__reathance__bad-808-12.wav.wav
    * url: https://freesound.org/s/482063/
    * license: Creative Commons 0
  * 482062__reathance__bad-808-13.wav.wav
    * url: https://freesound.org/s/482062/
    * license: Creative Commons 0
  * 482061__reathance__bad-808-1.wav.wav
    * url: https://freesound.org/s/482061/
    * license: Creative Commons 0
  * 482060__reathance__bad-808-6.wav.wav
    * url: https://freesound.org/s/482060/
    * license: Creative Commons 0
  * 482059__reathance__bad-808-5.wav.wav
    * url: https://freesound.org/s/482059/
    * license: Creative Commons 0
  * 482058__reathance__bad-808-8.wav.wav
    * url: https://freesound.org/s/482058/
    * license: Creative Commons 0
  * 482057__reathance__bad-808-7.wav.wav
    * url: https://freesound.org/s/482057/
    * license: Creative Commons 0
  * 482056__reathance__bad-808-2.wav.wav
    * url: https://freesound.org/s/482056/
    * license: Creative Commons 0
  * 482055__reathance__bad-808-16.wav.wav
    * url: https://freesound.org/s/482055/
    * license: Creative Commons 0
  * 482054__reathance__bad-808-4.wav.wav
    * url: https://freesound.org/s/482054/
    * license: Creative Commons 0
  * 482053__reathance__bad-808-3.mp3.mp3
    * url: https://freesound.org/s/482053/
    * license: Creative Commons 0


